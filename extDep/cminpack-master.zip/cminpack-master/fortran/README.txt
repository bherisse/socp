
This is non-modified version of Minpack library.

Downloaded from ftp://ftp.netlib.org/minpack/.

For Copyright see CopyrightMINPACK.txt.


Other resources:

http://en.wikipedia.org/wiki/MINPACK
http://www.netlib.org/minpack/
